$(function() {
	$(".book1").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4297103087.09.LZZZZZZZ");
	});
	$(".book2").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4866671734.09.LZZZZZZZ");
	});
	$(".book3").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4297130122.09.LZZZZZZZ");
	});
    $(".book4").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295008435.09.LZZZZZZZ");
	});
    $(".book5").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478108242.09.LZZZZZZZ");
	});
    $(".book6").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4046018631.09.LZZZZZZZ");
	});
    $(".book7").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4815602840.09.LZZZZZZZ");
	});
    $(".book8").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478105251.09.LZZZZZZZ");
	});
    $(".book9").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295011231.09.LZZZZZZZ");
	});
    $(".book10").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295005231.09.LZZZZZZZ");
	});
    $(".book11").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295003093.09.LZZZZZZZ");
	});
    $(".book12").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295007285.09.LZZZZZZZ");
	});
    $(".book13").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295012491.09.LZZZZZZZ");
	});
    $(".book14").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4910088121.09.LZZZZZZZ");
	});
    $(".book15").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478109206.09.LZZZZZZZ");
	});
    $(".book16").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799320599.09.LZZZZZZZ");
	});
    $(".book17").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4757414676.09.LZZZZZZZ");
	});
    $(".book18").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4757413319.09.LZZZZZZZ");
	});
    $(".book19").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4757413688.09.LZZZZZZZ");
	});
    $(".book20").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4761275774.09.LZZZZZZZ");
	});
    $(".book21").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4815610215.09.LZZZZZZZ");
	});
    $(".book22").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4910017224.09.LZZZZZZZ");
	});
    $(".book23").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478112673.09.LZZZZZZZ");
	});
    $(".book24").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4833424533.09.LZZZZZZZ");
	});
    $(".book25").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4198654387.09.LZZZZZZZ");
	});
    $(".book26").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4479796320.09.LZZZZZZZ");
	});
    $(".book27").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4801481051.09.LZZZZZZZ");
	});
    $(".book28").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827213240.09.LZZZZZZZ");
	});
    $(".book29").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827212619.09.LZZZZZZZ");
	});
    $(".book30").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827211698.09.LZZZZZZZ");
	});
    $(".book31").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4910216073.09.LZZZZZZZ");
	});
    $(".book32").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4569852734.09.LZZZZZZZ");
	});
    $(".book33").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827211965.09.LZZZZZZZ");
	});
    $(".book34").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4262174794.09.LZZZZZZZ");
	});
    $(".book35").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4046045698.09.LZZZZZZZ");
	});
    $(".book36").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827212147.09.LZZZZZZZ");
	});
    $(".book37").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4802613776.09.LZZZZZZZ");
	});
    $(".book38").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478372608.09.LZZZZZZZ");
	});
    $(".book39").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4802613199.09.LZZZZZZZ");
	});
    $(".book40").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4296107631.09.LZZZZZZZ");
	});
    $(".book41").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4065165369.09.LZZZZZZZ");
	});
    $(".book42").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4502168114.09.LZZZZZZZ");
	});
    $(".book43").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4774163015.09.LZZZZZZZ");
	});
    $(".book44").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799106945.09.LZZZZZZZ");
	});
    $(".book45").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4502342416.09.LZZZZZZZ");
	});
    $(".book46").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799328506.09.LZZZZZZZ");
	});
    $(".book47").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4837804985.09.LZZZZZZZ");
	});
    $(".book48").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478109575.09.LZZZZZZZ");
	});
    $(".book49").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4495540890.09.LZZZZZZZ");
	});
    $(".book50").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4866365080.09.LZZZZZZZ");
	});
    $(".book51").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799313134.09.LZZZZZZZ");
	});
    $(".book52").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4761273070.09.LZZZZZZZ");
	});
    $(".book53").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4492534032.09.LZZZZZZZ");
	});
    $(".book54").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478026122.09.LZZZZZZZ");
	});
    $(".book55").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799323628.09.LZZZZZZZ");
	});
    $(".book56").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4344039777.09.LZZZZZZZ");
	});
    $(".book57").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478069395.09.LZZZZZZZ");
	});
    $(".book58").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4833424118.09.LZZZZZZZ");
	});
    $(".book59").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4413019164.09.LZZZZZZZ");
	});
    $(".book60").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4766730275.09.LZZZZZZZ");
	});
    $(".book61").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4860634187.09.LZZZZZZZ");
	});
    $(".book62").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799320238.09.LZZZZZZZ");
	});
    $(".book63").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4905073618.09.LZZZZZZZ");
	});
    $(".book64").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4909417958.09.LZZZZZZZ");
	});
    $(".book65").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4769610041.09.LZZZZZZZ");
	});
    $(".book66").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4569832059.09.LZZZZZZZ");
	});
    $(".book67").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4903722848.09.LZZZZZZZ");
	});
    $(".book68").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799310380.09.LZZZZZZZ");
	});
    $(".book69").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478084947.09.LZZZZZZZ");
	});
    $(".book70").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4798175307.09.LZZZZZZZ");
	});
    $(".book71").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4838731221.09.LZZZZZZZ");
	});
    $(".book72").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799109642.09.LZZZZZZZ");
	});
    $(".book73").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4526080861.09.LZZZZZZZ");
	});
    $(".book74").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4788715929.09.LZZZZZZZ");
	});
    $(".book75").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4492045937.09.LZZZZZZZ");
	});
    $(".book76").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4408338192.09.LZZZZZZZ");
	});
    $(".book77").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478069557.09.LZZZZZZZ");
	});
    $(".book78").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4492502742.09.LZZZZZZZ");
	});
    $(".book79").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4863674287.09.LZZZZZZZ");
	});
    $(".book80").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4774518301.09.LZZZZZZZ");
	});
    $(".book81").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4046049308.09.LZZZZZZZ");
	});
    $(".book82").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4534058063.09.LZZZZZZZ");
	});
    $(".book83").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827213380.09.LZZZZZZZ");
	});
    $(".book84").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4905073618.09.LZZZZZZZ");
	});
    $(".book85").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4903722848.09.LZZZZZZZ");
	});
    $(".book86").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4492045937.09.LZZZZZZZ");
	});
    $(".book87").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4756920934.09.LZZZZZZZ");
	});
    $(".book88").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4862807372.09.LZZZZZZZ");
	});
    $(".book89").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295403954.09.LZZZZZZZ");
	});
    $(".book90").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4041106176.09.LZZZZZZZ");
	});
    $(".book91").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4569832903.09.LZZZZZZZ");
	});
    $(".book92").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4866213485.09.LZZZZZZZ");
	});
    $(".book93").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4827213380.09.LZZZZZZZ");
	});
    $(".book94").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4295406449.09.LZZZZZZZ");
	});
    $(".book95").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4023318507.09.LZZZZZZZ");
	});
    $(".book96").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478025258.09.LZZZZZZZ");
	});
    $(".book97").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478069786.09.LZZZZZZZ");
	});
    $(".book98").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4866630477.09.LZZZZZZZ");
	});
    $(".book99").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4478016828.09.LZZZZZZZ");
	});
    $(".book100").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799328085.09.LZZZZZZZ");
	});
    $(".book101").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4799322400.09.LZZZZZZZ");
	});
    $(".book102").hover(function() {
		$(".Product_image").attr("src","https://images-fe.ssl-images-amazon.com/images/P/4862762883.09.LZZZZZZZ");
	});
    
    $(document).ready(function(){
    $('a[href^=#]').click(function(){
        var speed = 800;
        var href= $(this).attr("href");
        var target = $(href == "#" || href == "" ? 'html' : href);
        var position = target.offset().top;
        $("html, body").animate({scrollTop:position}, speed, "swing");
        return false;
    });
});
});